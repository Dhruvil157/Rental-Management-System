package View;

import java.text.ParseException;
import java.util.Scanner;
import Controller.rentalController;
import Controller.tenantController;
import Util.rentalFactory;
import model.Apartment;
import model.Building;
import model.Condo;
import model.House;
import model.Tenant;

public class Driver {

	rentalController rc = new rentalController();
	tenantController tc = new tenantController();

	public static void main(String[] args) throws ParseException {
		System.out.println("\n*****	Welcome to Rental Services	*****\n\n");

		while (true) {
			new Driver().printMenu();
		}

	}

	/**
	 * Method to print the main menu for the customers.
	 * 
	 * @throws ParseException
	 */
	public void printMenu() throws ParseException {
		System.out.println("\nPlease choose your action from this menu :- \n1. Add A Property\n" + "2. Add A New Tenant\n"
				+ "3. Rent A Unit\n" + "4. Display Properties\n5. Display Registered Tenants\n"
				+ "6. Display Rented Properties\n7. Display Vacant Properties\n8. Display all The Signed Leases\n9. Change Rental Status");
		System.out.println("10. Exit");
		Scanner sc = new Scanner(System.in);
		int input = Integer.parseInt(sc.nextLine());
		switch (input) {
		case 1: {
			System.out.println("Please select your choice :\n1. Apartment\n2. Condo\n3. House");
			int ch = Integer.parseInt(sc.nextLine());
			
			Building model;
			switch (ch) {
			case 1: {
				model = getApartmentDetails();
				rc.addProperty(model);

				break;
			}
			case 2: {
				model = getCondoDetails();
				rc.addProperty(model);
				break;
			}
			case 3: {
				model = getHouseDetails();
				rc.addProperty(model);
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + ch);
			}

			break;
		}
		case 2: {
			Tenant newTenant = getTenantDetails();

			System.out.println("Are you interested in looking any of our preperties? (yes/no)");
			String ch = sc.nextLine();

			if (ch.equalsIgnoreCase("YES")) {
				rc.displayProperties();

				System.out.println("Please enter the property Ids that you are interested in : ");
				String interestedIds = sc.nextLine();

				String[] propertyIds = interestedIds.split(" ");
				for (String s : propertyIds) {
					Building building = rc.getProperty(s);
					tc.addInterestedProperty(newTenant, building);
				}
			}

			tc.addTenant(newTenant);
			break;
		}
		case 3: {

			System.out.println("Please enter your tenant id : ");
			String tId = sc.nextLine();

			
			boolean propertyAvailability = rc.displayVacantProperties();
			if (propertyAvailability) {
				System.out.println("No property available for rent!!\n");
			} else {

				System.out.println("Enter property ID from above : ");
				String pId = sc.nextLine();

				System.out.println("Please enter the email of the tenant:");
				String emailId = sc.nextLine();
				System.out.println("Please enter the start date of the lease in the format dd/mm/yyyy:");
				String startDate = sc.nextLine();
				System.out.println("Please enter the end date of the lease in the format dd/mm/yyyy:");
				String endDate = sc.nextLine();
				System.out.println("Please enter the monthly rent :");
				int rent = Integer.parseInt(sc.nextLine());

				Tenant tenant = tc.getTenant(tId);
				rc.rentProperty(pId, tenant, emailId, startDate, endDate, rent);
				tc.myProperty(pId, tId);
			}
			break;
		}
		case 4: {
			rc.displayProperties();

			break;
		}
		case 5: {
			tc.displayTenant();
			break;
		}
		case 6: {
			rc.displayRentedProperties();
			break;
		}
		case 7: {
			rc.displayVacantProperties();

			break;
		}
		case 8: {
			rc.displayLeases();
			break;
		}
		case 9: {
			rc.displayRentedProperties();
			System.out.println("Please enter the property Ids whose rent period is over : ");
			String interestedIds = sc.nextLine();
			String[] propertyIds = interestedIds.split(" ");
			for (String s : propertyIds) {
				Building building = rc.getProperty(s);
				if (building instanceof Apartment) {
					Apartment apartment = (Apartment) building;
					apartment.setIsRented(false, apartment);
					//System.out.println("Apartment is free now..");
				} else if (building instanceof Condo) {
					Condo condo = (Condo) building;
					condo.setIsRented(false, condo);
					//System.out.println("Condo is free now..");
				} else if (building instanceof House) {
					House house = (House) building;
					house.setIsRented(false, house);
					//System.out.println("House is free now..");
				}

				// tc.addInterestedProperty(building);
			}
			break;
		}
		case 10: {
			System.err.println(
					"\n\n********************************************\n\nThank you for using our service! \nHave a good day!!\n\n********************************************");
			System.exit(0);
			break;
		}
		default: {
			System.err.println("\nThis is not a valid Menu option! Please select another option.\n");
			break;
		}
		}
	}

	private static Tenant getTenantDetails() {
		// TODO Auto-generated method stub

		Tenant tenant = new Tenant();
		Scanner sc = new Scanner(System.in);

		System.out.println("First Name : ");
		tenant.setFirstName(sc.nextLine());
		System.out.println("Last Name : ");
		tenant.setLastName(sc.nextLine());
		System.out.println("Age : ");
		tenant.setAge(Integer.parseInt(sc.nextLine()));
		System.out.println("Contact Number : ");
		tenant.setContactNumber(sc.nextLine());
		System.out.println("Email id : ");
		tenant.setEmail(sc.nextLine());

		return tenant;

	}

	private static void printMessage() {
		System.out.println("Data added successfully.");
	}

	private static Apartment getApartmentDetails() {

		Apartment apartment = new Apartment();
		Scanner sc = new Scanner(System.in);

		System.out.println("Civic Address : ");
		apartment.setCivicAddress(sc.nextLine());
		System.out.println("Apartment Number : ");
		apartment.setApartmentNumber(sc.nextLine());
		System.out.println("Number of Bedrooms : ");
		apartment.setNoOfBedrooms(Integer.parseInt(sc.nextLine()));
		System.out.println("Number of Bathrooms : ");
		apartment.setNoOfBathrooms(Integer.parseInt(sc.nextLine()));
		System.out.println("Square Foot Area : ");
		apartment.setSquareFootage(Integer.parseInt(sc.nextLine()));
		System.out.println("Street Name : ");
		apartment.setStreetName(sc.nextLine());
		System.out.println("City : ");
		apartment.setCity(sc.nextLine());
		System.out.println("Postal Code : ");
		apartment.setPostalCode(sc.nextLine());
		System.out.println("Province : ");
		apartment.setProvince(sc.nextLine());
		System.out.println("Country : ");
		apartment.setCountry(sc.nextLine());

		return apartment;
	}

	private static Condo getCondoDetails() {

		Condo condo = new Condo();
		Scanner sc = new Scanner(System.in);

		System.out.println("Unit Number : ");
		condo.setUnitNumber(Integer.parseInt(sc.nextLine()));
		System.out.println("Street Number:");
		condo.setStreetNumber(Integer.parseInt(sc.nextLine()));
		System.out.println("Street Name :");
		condo.setStreetName(sc.nextLine());
		System.out.println("City :");
		condo.setCity(sc.nextLine());
		System.out.println("Postal Code :");
		condo.setPostalCode(sc.nextLine());
		System.out.println("Province :");
		condo.setProvince(sc.nextLine());
		System.out.println("Country :");
		condo.setCountry(sc.nextLine());

		return condo;
	}

	private static House getHouseDetails() {

		House house = new House();
		Scanner sc = new Scanner(System.in);

		System.out.println("Street Number:");
		house.setStreetNumber(Integer.parseInt(sc.nextLine()));
		System.out.println("Street Name :");
		house.setStreetName(sc.nextLine());
		System.out.println("City :");
		house.setCity(sc.nextLine());
		System.out.println("Postal Code :");
		house.setPostalCode(sc.nextLine());
		System.out.println("Province :");
		house.setProvince(sc.nextLine());
		System.out.println("Country :");
		house.setCountry(sc.nextLine());

		return house;
	}
}


